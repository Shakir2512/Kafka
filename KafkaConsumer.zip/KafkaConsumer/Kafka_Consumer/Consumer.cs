﻿
using KafkaNet;
using KafkaNet.Model;
using KafkaNet.Protocol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kafka_Consumer
{
    public class Consumer
    {
        public string Consumers(string url)
        {
            StringBuilder messages = new StringBuilder();
            try
            {
                //string topic = "ACK";
                string topic = "TestA"; //"MDM.SIT.PRODUCTACCO.PUB";
                Uri uri = new Uri(url);
                int count = 1; int messageCountS = 0;
                var options = new KafkaOptions(uri);
                var router = new BrokerRouter(options);

                //
         //       OffsetPosition[] offsetPositions = new OffsetPosition[]
         //{
         //   new OffsetPosition()
         //   {
         //      Offset = 0,
         //      PartitionId = 1
         //   }
         //};

                var consumer = new KafkaNet.Consumer(new ConsumerOptions(topic,
      router));
                var result = consumer.Consume();
                // foreach (var item in result)
                // {
                //     Console.WriteLine("Response: Partition={0},offset={1}: data={2}",
                //item.Meta.PartitionId, item.Meta.Offset,
                //Encoding.UTF8.GetString(item.Value));
                //     Console.WriteLine($"Response: Partition ={item.Meta.PartitionId},offset={item.Meta.Offset},data={Encoding.UTF8.GetString(item.Value)}");
                // }
                // Console.ReadLine();
                List<KafkaNet.Protocol.OffsetPosition> offsetPosition = consumer.GetOffsetPosition().ToList();
                var messageCount = offsetPosition.ToList();

                for (int i = messageCount.Count - 1; i < messageCount.Count; i++)
                {
                    messages.Append(Encoding.UTF8.GetString(result.FirstOrDefault().Value));
                }
                //foreach (var message in result)
                //{
                //    List<KafkaNet.Protocol.OffsetPosition> offsetPosition = consumer.GetOffsetPosition().ToList();
                //    var messageCount = offsetPosition.ToList();
                //    foreach (var msgs in messageCount)
                //    {
                //        messageCountS = Convert.ToInt32(msgs.Offset);
                //    }
                //    if (count <= messageCountS - 1)
                //    {
                //        count += 1;
                //        messages.Append(Encoding.UTF8.GetString(message.Value));

                //    }
                //    else if (count == messageCountS)
                //    {
                //        messages.Clear();
                //        messages.Append(Encoding.UTF8.GetString(message.Value));
                //        // Console.Clear();
                //        // Console.WriteLine(messages);
                //        // Console.ReadLine();

                //        break;

                //    }
                //}
            }

            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

            return messages.ToString();

        }
    }
}
