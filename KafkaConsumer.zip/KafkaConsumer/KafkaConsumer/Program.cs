﻿
namespace KafkaConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Kafka_Consumer.Consumer obj = new Kafka_Consumer.Consumer();
           var test= obj.Consumers("http://192.168.1.108:9092");//http://10.24.2.76:9092
        }
    }
}
